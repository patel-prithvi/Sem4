from django.db import models

# Create your models here.

class Member(models.Model):
    name = models.CharField(max_length=100)
    plan = models.CharField(max_length=50)
    fee = models.DecimalField(max_digits=8, decimal_places=2)