from django.shortcuts import render, redirect, get_object_or_404
from .models import Member

# Home View: Handles listing and searching by name (first field)
def home(request):
    search_query = request.GET.get('search', '')
    if search_query:
        members = Member.objects.filter(name__icontains=search_query)
    else:
        members = Member.objects.all()
    
    return render(request, 'home.html', {'members': members, 'search_query': search_query})

# Add Member View
def add_member(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        plan = request.POST.get('plan')
        fee = request.POST.get('fee')
        
        Member.objects.create(name=name, plan=plan, fee=fee)
        return redirect('home')
        
    return render(request, 'member_form.html', {'action': 'Add'})

# Edit Member View
def edit_member(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        member.name = request.POST.get('name')
        member.plan = request.POST.get('plan')
        member.fee = request.POST.get('fee')
        member.save()
        return redirect('home')
        
    return render(request, 'member_form.html', {'member': member, 'action': 'Edit'})

# Delete Member View
def delete_member(request, pk):
    member = get_object_or_404(Member, pk=pk)
    if request.method == 'POST':
        member.delete()
        return redirect('home')
    return render(request, 'delete_confirm.html', {'member': member})
