from django.shortcuts import render

# Create your views here.
from .models import Player
from django.shortcuts import get_object_or_404,redirect

def home(request):
    search=request.GET.get('search')
    if search:
        players=Player.objects.filter(name__icontains=search)
    else:
        players=Player.objects.all()
    return render(request,'home.html',{'players':players})

def welcome(request):
    return render(request, 'welcome.html')


def add_player(request):
    if request.method == "POST":
        Player.objects.create(
            name=request.POST['name'], 
            test_innings=request.POST['innings'],
            runs=request.POST['runs'])
        return redirect('/') 
    return render(request, 'add_player.html')

def edit_player(request, id):
    player = Player.objects.get(id=id)
    if request.method == "POST":
        player.name = request.POST['name']
        player.test_innings = request.POST['innings'] 
        player.runs = request.POST['runs']
        player.save()
        return redirect('/') 
    return render(request, 'edit_player.html', {'player': player})

def delete_player(request, id):
    player = Player.objects.get(id=id)
    player.delete()
    return redirect('/')
